﻿AISatyagrah Peer GPU Agent
==========================
1) Put your shared secret in secret.txt (or set SATYAGRAH_SECRET).
2) Double-click PeerAgent.exe.
3) Control panel: http://127.0.0.1:8090
   - GPU Share slider (0–100%)
   - Daily limit
   - Pause / Resume / Quit
4) Put job_*.zip into inbox/. Results appear in out/.
